import React from 'react'
import logo from '../assets/logo.png'; 
import { Link, useNavigate } from 'react-router-dom';

const Forgotpass = () => {
  const navigate = useNavigate();
  return (
    <div className="flex w-full h-screen">
      <div className="w-1/2 flex items-center justify-center bg-white">
        <img src={logo} alt="May Fashion Logo" className="w-96" />
      </div>
      <div className="w-1/2 flex items-center justify-center bg-[#00AF96] p-4 rounded-l-3xl">
        <div className="bg-white p-10 rounded-lg shadow-lg w-full max-w-md">
            <h1 className="mx-20 text-2xl font-bold mb-1">Forgot Password?</h1>
            <div className="mt-2 text-center text-sm text-gray-600">
              Remember your password?{' '}
              <Link to="/" className="font-medium text-blue-500 hover:text-black hover:underline">
                Login here
              </Link>
            </div>
            <form className="mt-4">
              <label className="mt-4 text-left text-sm text-gray-600 block" htmlFor="email-input">
                Email address
              </label>
              <div className="mb-4">
                <input
                  id="email-input"
                  type="email"
                  placeholder="Email"
                  className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-[#28b584]"
                />
              </div>
              <button
                type="submit"
                onClick={() => navigate("/checkmail")}
                className="w-full bg-[#C7F5EE] text-black py-2 rounded-md hover:bg-[#c7f5eeb4]"
              >
                Reset Password   
              </button>
            </form>
        </div>
      </div>
    </div>
  )
}

export default Forgotpass
