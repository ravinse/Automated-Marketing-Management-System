import React from 'react'
import logo from '../assets/logo.png'; 
import { Link, useNavigate } from 'react-router-dom';

const Register = () => {
  const navigate = useNavigate();
  return (
    <div className="flex w-full h-screen">
      <div className="w-1/2 flex items-center justify-center bg-white">
        <img src={logo} alt="May Fashion Logo" className="w-96" />
      </div> 
      <div className="w-1/2 flex items-center justify-center bg-[#00AF96] p-8 rounded-l-3xl">
        <div className="bg-white p-10 rounded-lg shadow-lg w-full max-w-md">
          <h2 className="text-2xl font-bold mb-1">Sign Up</h2>
          <p className="text-gray-600 mb-6">Welcome to May Fashion</p>

          <form>
            <div className="mb-4">
              <input
                type="text"
                placeholder="Name"
                className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-[#28b584]"
              />
            </div>

            <div className="mb-4">
                <input
                type="email"
                placeholder="Email"
                className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-[#28b584]"/>
            </div>

            <div className="mb-4">
                <input
                    type="text"
                    placeholder="Username"
                    className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-[#28b584]"
                />  
            </div>

            <div className="mb-4 relative">
              <input
                type="password"
                placeholder="Password"
                className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-[#28b584]"
              />
              <span className="absolute right-3 top-2.5 text-gray-500 cursor-pointer">
                Show
              </span>
            </div>

            <div className="mb-4 relative">
                <input
                    type="password"
                    placeholder="Confirm Password"
                    className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-[#28b584]"/>
                <span className="absolute right-3 top-2.5 text-gray-500 cursor-pointer">
                    Show
                    </span>
            </div>

            <input
              type="checkbox"
                className="mr-2 mx-16 mb-4"    
            />
            <span className="text-gray-500 text-sm">I agree to the terms and conditions</span>
            <button
              type="submit"
              onClick={() => navigate("/")}
              className="w-full bg-black text-white py-2 rounded-md hover:bg-gray-800"
            >
              Register
            </button>
          </form>


          <div className="mt-4 text-center">
            <Link to="/" type="submit"
            className="text-gray-500 text-sm hover:underline">
              Sign in
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Register
