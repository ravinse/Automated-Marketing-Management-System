import React from 'react';
import {BrowserRouter, Route, Routes} from 'react-router-dom';
import Login from './components/Login';
import Register from './components/Register';
import Forgotpass from './components/Forgotpass';
import Changepass from './components/Changepass';
import Checkmail from './components/Checkmail';
import Changesucc from './components/Changesucc';

export default function App() {
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Login />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/forgotpass" element={<Forgotpass />} />
          <Route path="/checkmail" element={<Checkmail />} />
          <Route path="/changepass" element={<Changepass />} />
          <Route path="/changesucc" element={<Changesucc />} />
        </Routes>
      </BrowserRouter>
    </>
  )
}
